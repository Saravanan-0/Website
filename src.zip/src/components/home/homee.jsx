import React from 'react'
import About from '../home/about/about'
import Service from '../home/services/service'

import Home from '../home/Home'
import Interest from './interest/interest'

const Homee = () => {
  return (
    <div className='Homee'>
    <Home/>
    <About/>
    <Service/>
    <Interest/>
    
    </div>
  )
}

export default Homee