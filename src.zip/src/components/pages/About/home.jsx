
import Navbar from '../../Common/navbar/navbar'
import Footer from '../../Common/Footer/footer'
import About from './about1'

const About11 = () => {
    return (
      <>
      {/* <Navbar/> */}
      <About/>
      {/* <Footer/> */}
      
      </>
    )
  }
  
  export default About11