import React from "react";
import './creative.css'
import serv2 from "../../Creative/creative/assets/image.svg"
import head2 from "../../Creative/creative/assets/creative.svg"

 
let Develop = ()=>{
    return(
        
        <div id="con" className="development">
            <div className="box19">
                <img className="devimg9" src={serv2}/>
                <div className="box-text9">
                <div className="head-main9">
                <div className="head491">Creative Services</div>
                <div className="head492">Creative Services</div>
               </div>
                <p className="create9">
Range of services that involve the creation of visual and multimedia content for various purposes, such as marketing, advertising, branding, and communication.</p>
                      </div>
            </div>
 
        </div>
 
    )
}
export default Develop