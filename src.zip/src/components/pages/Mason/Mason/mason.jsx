import React from "react";
import './mason.css'
import serv2 from "../../Mason/Mason/assets/image.svg"
import head2 from "../../Mason/Mason/assets/mason.svg"

 
let Develop = ()=>{
    return(
        
        <div id="con" className="development">
            <div className="box75">
                <img className="devimg75" src={serv2}/>
                <div className="box-text75">
                <div className="head-main75">
                <div className="head475">Mason Services</div>
                <div className="head476">Mason Services</div>
               </div>
                <p className="create75">In Mason services we build your dream business, stabilize the operations and transfer in the situation where you can take over the full control and operate it by yourself.</p>
                      </div>
            </div>
 
        </div>
 
    )
}
export default Develop