import React from "react";
import './meta.css'
import serv1 from "../metaverse/assets/serv1.svg"
import head1 from "../metaverse/assets/meta.svg"


 
let User = ()=>{
    return(
        
        <div id="metaverse" className="user">
            <div className="box1">
                <img className="devimg3" src={serv1}/>
                <div className="box-text3">
                <div className="head-main31">
                <div className="head431">Metaverse</div>
                <div className="head432">Metaverse</div>
               </div>
                <p className="create3">Capitalize on the metaverse opportunity with our deep expertise in AR/VR and AI.
Our developers ensure your metaverse venture is future-ready for success by building 3D virtual spaces, virtual avatars, and virtual games.</p>
                      </div>
            </div>
 
        </div>
 
    )
}
export default User